﻿# $scriptPath = 'C:\Users\erickremote\Downloads\webp converter\dark'
$scriptPath = 'C:\Users\erickremote\Downloads\webp converter\Seed Logos'
$fileNames = Get-ChildItem -Path $scriptPath -Recurse -Include *.png,*.ico,*.jpg, *.jpeg
cd $scriptPath
foreach ($f in $fileNames){
    echo $f
    $outfile = $scriptPath + "\webp\" + $f.BaseName + ".webp"
    echo $outfile
    C:\Users\erickremote\Downloads\webp converter\win-x64-cwebp.exe $f.FullName -o $outfile
    Get-Content $f.FullName | Where-Object { ($_ -match 'step4' -or $_ -match 'step9') } | Set-Content $outfile
}
